# テーマ設定
[[WPF] Windows 10に馴染むテーマを適用する #Windows10 - Qiita](https://qiita.com/Kosen-amai/items/607b9ba3af9222aa7225)

# ホットキーの設定
[c#でのホットキー設定方法 #C# - Qiita](https://qiita.com/niwanowa/items/7328a438f38e9b0bdd81)

# タスクトレイ
[WPFでタスクトレイ常駐アプリを作る #C# - Qiita](https://qiita.com/TiggeZaki/items/aa17edbef0cc5f4736d9)