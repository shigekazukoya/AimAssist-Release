# プレゼンテーション層
MainWindow

HotKeys

# Application層
モード
サブモード
カテゴリ
ユニット

ユニット の単位
    モード (サブモード)
    カテゴリ
    Name
    Text
    UIElement
    アイコン

WorkFolow
    カテゴリ
    Name
    UIElement

BookSearch
    Title
    URL

ユニットサービス

# Domain層
Snippet
    カテゴリ
    Name
    Code

Command
    Name
    Action

リンク
    Name
    Path

ブックマーク
    カテゴリ FullPath
    Name
    URL

Snippetサービス

# インフラ
WebView
    MarkdownView

AmazonURL

GoogleBooksAPIs