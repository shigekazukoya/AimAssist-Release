[Microsoft Edge WebView2 | Microsoft Edge Developer](https://developer.microsoft.com/ja-jp/microsoft-edge/webview2/?form=MA13LH)

[C# WebView2を通じてWebサーバーなしでJavaScriptからローカルファイルを読み書き](https://chishiki21.blogspot.com/2021/10/step-by-step-webview2webjavascript.html)

[📚ブラウザの仕組みを学ぶ](https://zenn.dev/silverbirder/articles/e10295948e17ca)